// Remplacez par les valeurs de Supabase > Project Settings > API
var SUPABASE_URL='https://VOTRE-PROJET.supabase.co';
var SUPABASE_KEY='VOTRE_CLE_ANON_PUBLIQUE';
