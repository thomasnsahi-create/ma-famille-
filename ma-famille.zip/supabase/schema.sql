-- Ma Famille : schéma Supabase (à coller dans SQL Editor puis Run)
-- ATTENTION : cette première partie EFFACE les anciennes tables et leurs données (réinstallation propre).
drop table if exists messages, votes, unites, personnes cascade;
drop function if exists moi(), membre_unite(uuid,uuid), est_chef_de(uuid), peut_ajouter(uuid,uuid,uuid), peut_lire(text), reclamer(uuid), t_perso(), t_vote(), rappels_du_jour();
create extension if not exists pgcrypto;

create table personnes(
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references auth.users(id) on delete set null,
  nom text not null, sexe char(1) check (sexe in ('M','F')),
  naissance date, deces date, mariage date, photo text,
  nai_annee_seule boolean not null default false, dec_annee_seule boolean not null default false,
  pere uuid references personnes(id) on delete set null,
  mere uuid references personnes(id) on delete set null,
  conjoint uuid references personnes(id) on delete set null);
create table unites(
  id uuid primary key default gen_random_uuid(),
  parent1 uuid references personnes(id) on delete cascade,
  parent2 uuid references personnes(id) on delete cascade,
  chef uuid references personnes(id) on delete set null);
create table votes(
  unite uuid references unites(id) on delete cascade,
  votant uuid references personnes(id) on delete cascade,
  candidat uuid references personnes(id) on delete cascade,
  primary key(unite,votant));
create table messages(
  id bigserial primary key, canal text not null,
  auteur uuid references personnes(id) on delete set null,
  texte text not null, photo text, cree timestamptz default now());
create index on messages(canal,cree);

-- Fonctions utilitaires
create function moi() returns uuid language sql stable security definer set search_path=public as
$$ select id from personnes where user_id=auth.uid() $$;

create function membre_unite(u uuid,p uuid) returns boolean language sql stable security definer set search_path=public as
$$ select coalesce(exists(select 1 from unites x where x.id=u and (p in (x.parent1,x.parent2)
   or exists(select 1 from personnes c where c.id=p and c.pere is not distinct from x.parent1 and c.mere is not distinct from x.parent2))),false) $$;

create function est_chef_de(p uuid) returns boolean language sql stable security definer set search_path=public as
$$ select exists(select 1 from unites u where u.chef=moi() and membre_unite(u.id,p)) $$;

create function peut_ajouter(a uuid,b uuid,c uuid) returns boolean language sql stable security definer set search_path=public as
$$ select coalesce(
   exists(select 1 from unites u where u.chef=moi() and
     (membre_unite(u.id,a) or membre_unite(u.id,b) or membre_unite(u.id,c)))
   or (moi() in (a,b,c) and not exists(select 1 from unites u where moi() in (u.parent1,u.parent2))),
   false) $$;

create function peut_lire(c text) returns boolean language sql stable security definer set search_path=public as
$$ select c='fam'
   or (c like 'u:%' and membre_unite(substr(c,3)::uuid,moi()))
   or (c like 'p:%' and moi()::text = any(string_to_array(substr(c,3),'_'))) $$;

create function reclamer(p uuid) returns void language sql security definer set search_path=public as
$$ update personnes set user_id=auth.uid() where id=p and user_id is null
   and not exists(select 1 from personnes where user_id=auth.uid()) $$;

-- Conjoint réciproque + création automatique des sous-familles
create function t_perso() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if new.conjoint is not null then
    update personnes set conjoint=new.id, mariage=coalesce(new.mariage,mariage)
      where id=new.conjoint and conjoint is distinct from new.id;
  end if;
  if (new.pere is not null or new.mere is not null) and not exists(
      select 1 from unites where parent1 is not distinct from new.pere and parent2 is not distinct from new.mere) then
    insert into unites(parent1,parent2,chef) values(new.pere,new.mere,coalesce(new.pere,new.mere));
  end if;
  return new;
end $$;
create trigger t_perso after insert or update on personnes for each row execute function t_perso();

-- Le chef de sous-famille = candidat le plus voté
create function t_vote() returns trigger language plpgsql security definer set search_path=public as $$
declare u uuid := coalesce(new.unite,old.unite); c uuid;
begin
  select candidat into c from votes where unite=u group by candidat order by count(*) desc, candidat limit 1;
  if c is not null then update unites set chef=c where id=u; end if;
  return null;
end $$;
create trigger t_vote after insert or update or delete on votes for each row execute function t_vote();

-- Sécurité (RLS)
alter table personnes enable row level security;
alter table unites enable row level security;
alter table votes enable row level security;
alter table messages enable row level security;
revoke all on all tables in schema public from anon;
revoke update on personnes from authenticated;
grant update(nom,sexe,naissance,nai_annee_seule,deces,dec_annee_seule,mariage,photo,pere,mere,conjoint) on personnes to authenticated;

create policy p_sel on personnes for select to authenticated using(true);
create policy p_ins on personnes for insert to authenticated with check(
  (not exists(select 1 from personnes) and user_id=auth.uid())
  or (user_id is null and peut_ajouter(pere,mere,conjoint)));
create policy p_upd on personnes for update to authenticated using(id=moi() or est_chef_de(id));
create policy p_del on personnes for delete to authenticated using(id<>moi() and est_chef_de(id));

create policy u_sel on unites for select to authenticated using(true);

create policy v_sel on votes for select to authenticated using(true);
create policy v_ins on votes for insert to authenticated with check(votant=moi() and membre_unite(unite,moi()) and membre_unite(unite,candidat));
create policy v_upd on votes for update to authenticated using(votant=moi()) with check(votant=moi() and membre_unite(unite,candidat));
create policy v_del on votes for delete to authenticated using(votant=moi());

create policy m_sel on messages for select to authenticated using(peut_lire(canal));
create policy m_ins on messages for insert to authenticated with check(auteur=moi() and peut_lire(canal));
alter publication supabase_realtime add table messages;

-- Rappels automatiques (anniversaires, mariages, décès) vers la conversation de toute la famille
create function rappels_du_jour() returns void language sql security definer set search_path=public as $$
  insert into messages(canal,texte,photo)
  select 'fam','🎂 Joyeux anniversaire '||nom||' ! '||(extract(year from current_date)::int-extract(year from naissance)::int)||' ans aujourd’hui.',photo
    from personnes where deces is null and naissance is not null and not nai_annee_seule and to_char(naissance,'MM-DD')=to_char(current_date,'MM-DD')
  union all
  select 'fam','💍 Joyeux anniversaire de mariage à '||a.nom||' et '||b.nom||' : '||(extract(year from current_date)::int-extract(year from a.mariage)::int)||' ans !',a.photo
    from personnes a join personnes b on b.id=a.conjoint
    where a.id<b.id and a.mariage is not null and to_char(a.mariage,'MM-DD')=to_char(current_date,'MM-DD')
  union all
  select 'fam','🕯️ Aujourd’hui, nous pensons à '||nom||', décédé(e) il y a '||(extract(year from current_date)::int-extract(year from deces)::int)||' ans.',photo
    from personnes where deces is not null and not dec_annee_seule and to_char(deces,'MM-DD')=to_char(current_date,'MM-DD');
$$;
-- Activez l’extension pg_cron (Database > Extensions) puis exécutez :
-- select cron.schedule('rappels','0 7 * * *','select rappels_du_jour()');
