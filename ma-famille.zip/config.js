// Remplacez les deux valeurs par celles de Supabase > Project Settings > API
var SUPABASE_URL='https://VOTRE-PROJET.supabase.co';
var SUPABASE_KEY='VOTRE_CLE_ANON_PUBLIQUE';
// Connexion par e-mail seul (sans code). Mettre true pour exiger aussi un mot de passe.
var MODE_MDP=false;
