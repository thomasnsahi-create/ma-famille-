# Ma Famille : mise en ligne gratuite

1. Créez un compte gratuit sur supabase.com, puis un projet.
2. SQL Editor > New query : collez `supabase/schema.sql` > Run.
3. Authentication > Providers > Email : désactivez « Confirm email » (connexion immédiate).
4. Project Settings > API : copiez l'URL et la clé « anon public » dans `config.js`.
5. Hébergez le dossier gratuitement (Netlify Drop : glissez le dossier sur app.netlify.com/drop, ou GitHub Pages).
6. Ouvrez le site, créez un compte : le premier inscrit crée sa fiche (racine de la famille). Il ajoute ensuite les membres de sa sous-famille ; les autres s'inscrivent et choisissent « C'est moi ».
7. Rappels automatiques : Database > Extensions > activez pg_cron, puis exécutez la dernière ligne (commentée) de schema.sql.
8. Sur téléphone : ouvrez le site puis « Ajouter à l'écran d'accueil ».

Appels : via Jitsi Meet (gratuit) ; le lien est envoyé dans la conversation.
Sécurité : après l'arrivée de tous les membres, désactivez les inscriptions (Authentication > Sign In / Providers).
